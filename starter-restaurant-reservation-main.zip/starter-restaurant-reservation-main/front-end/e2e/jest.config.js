module.exports = {
  preset: "jest-puppeteer",
  testTimeout: 8000,
};
